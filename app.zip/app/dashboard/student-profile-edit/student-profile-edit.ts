import { Component } from '@angular/core';

@Component({
  selector: 'app-student-profile-edit',
  imports: [],
  templateUrl: './student-profile-edit.html',
  styleUrl: './student-profile-edit.scss',
})
export class StudentProfileEdit {

}
