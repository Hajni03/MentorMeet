import { Component } from '@angular/core';

@Component({
  selector: 'app-trust-bar',
  imports: [],
  templateUrl: './trust-bar.html',
  styleUrl: './trust-bar.scss',
})
export class TrustBar {

}
