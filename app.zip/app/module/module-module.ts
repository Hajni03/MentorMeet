import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Navbar } from '../core/navbar/navbar';



@NgModule({
  declarations: [],
  imports: [
    CommonModule
  ]
})
export class ModuleModule { }
