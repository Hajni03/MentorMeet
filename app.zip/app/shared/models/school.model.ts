export interface School {
  id: number;
  nev: string;
  cim: string;
  telefon: string;
  email: string;
  web: string;
  aktiv: boolean;
}