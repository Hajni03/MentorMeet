import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-register-choice',
  standalone: true,
  imports: [RouterLink],
  templateUrl: './register-choice.html',
  styleUrl: './register-choice.scss',
})
export class RegisterChoice {

}
